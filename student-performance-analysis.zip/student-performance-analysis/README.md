# Student Performance Analysis

Author: **Muhammad Fathan**

A beginner-friendly data analysis and machine learning project that explores factors affecting student performance and builds a simple predictive model.

## Objective
- Perform exploratory data analysis (EDA) on a synthetic student dataset.
- Build a simple regression model to predict final exam scores.
- Learn data cleaning, visualization, model training, and evaluation.

## Files
- `data/student_scores.csv` : Synthetic dataset (randomly generated).
- `notebooks/student_performance_analysis.ipynb` : Jupyter notebook with EDA and a Linear Regression example.
- `requirements.txt` : Python dependencies.

## Quick start
1. Clone the repository.
2. Create and activate a virtual environment (optional but recommended).
3. Install dependencies:
```bash
pip install -r requirements.txt
```
4. Run Jupyter:
```bash
jupyter notebook notebooks/student_performance_analysis.ipynb
```

## Notes
- The dataset is synthetic and generated for learning purposes.
- Feel free to extend the notebook with additional models (Decision Tree, Random Forest), or deploy with Streamlit.
